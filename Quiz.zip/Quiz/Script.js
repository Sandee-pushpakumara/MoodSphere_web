let currentQuestionIndex = 0;
const questions = document.querySelectorAll(".question");

document.getElementById("nextButton").addEventListener("click", showNextQuestion);

document.getElementById("quiz-form").addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent form submission

  const answers = collectAnswers();
  const score = calculateScore(answers);

  displayResult(score);
});

function showNextQuestion() {
  questions[currentQuestionIndex].classList.add("hidden");

  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    questions[currentQuestionIndex].classList.remove("hidden");
  } else {
    document.getElementById("nextButton").classList.add("hidden");
    document.getElementById("submitButton").classList.remove("hidden");
  }
}

function collectAnswers() {
  const answers = [];

  questions.forEach(function(question) {
    const selectedOption = question.querySelector('input[name^="q"]:checked');
    if (selectedOption) {
      answers.push(selectedOption.value);
    }
  });

  return answers;
}

function calculateScore(answers) {
  let score = 0;

  answers.forEach(function(answer) {
    if (answer === "yes") {
      score++;
    }
  });

  return score;
}

function displayResult(score) {
  const resultContainer = document.getElementById("result");
  resultContainer.innerHTML = "";

  if (score <= 2) {
    resultContainer.innerHTML = "<h3>Your mental state is good.</h3>";
  } else if (score <= 5) {
    resultContainer.innerHTML = "<h3>You may be experiencing some mild mental health issues. Consider seeking support.</h3>";
  } else {
    resultContainer.innerHTML = "<h3>You may be facing significant mental health challenges. Please seek professional help.</h3>";
  }

  resultContainer.classList.remove("hidden");
}

